package com.java.layer3;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.InsuranceHistory;
import com.java.layer2.Vehicle;


public class DAOImplTest {
	
	@Test
	public void testAllVehicles()
	{
		System.out.println("started DAO testing...");
	
		InsuranceHistoryDAO insuranceHistoryDAO = new InsuranceHistoryDAOImpl();

	Assertions.assertTrue(insuranceHistoryDAO!=null);

		List<InsuranceHistory> inshList=insuranceHistoryDAO.selectAllInsuranceHistory();
	Assertions.assertTrue(inshList.size() > 0 );

		for (InsuranceHistory insuranceHistory : inshList) {
			System.out.println("Vehicle : "+insuranceHistory);
		}

	}
	
	@Test
	public void testFindInsuranceHistory()
	{
		System.out.println("started DAO testing...");
		System.out.println("hello");
		InsuranceHistoryDAO insuranceHistoryDAO = new InsuranceHistoryDAOImpl();

	Assertions.assertTrue(insuranceHistoryDAO!=null);

		List<InsuranceHistory> inshList = insuranceHistoryDAO.findInsuranceHistory(102);
	 Assertions.assertTrue(inshList.size() > 0 );

		for (InsuranceHistory insuranceHistory : inshList) {
			System.out.println("Insurance History : "+insuranceHistory);
		}
		
	}

	@Test
	public void testLoadSingleVehicle()
	{
		System.out.println("started DAO testing...");
		
		VehicleDAO vehicleDAO = new VehicleDAOImpl();
		
		Assertions.assertTrue(vehicleDAO!=null);
		
		Vehicle vehicle=vehicleDAO.selectVehicle("AABB11");
		Assertions.assertTrue(vehicle!=null );
		
		System.out.println("Vehicle : "+vehicle);
		
	}

	@Test
	public void testAddSingleVehicle()
	{
		System.out.println("started DAO testing...");

		VehicleDAO vehicleDAO = new VehicleDAOImpl();	
		Assertions.assertTrue(vehicleDAO!=null);

		Vehicle vehicle=new Vehicle();
		Assertions.assertTrue(vehicle!=null);

		vehicle.setRcNumber("dummyRC");
		vehicle.setChasisNumber(999);
		
		
		vehicle.setDateOfPurchase(Date.valueOf("2019-3-22"));
		vehicle.setManufacturer("dummymanf");
		vehicle.setEngineNumber("dummyengine");
		vehicle.setVehicleModel("dummymodel");
		vehicle.setCost(500000);
		
		System.out.println("Vehicle : "+vehicle);
		vehicleDAO.insertVehicle(vehicle);
		System.out.println("Vehicle added....");
	}

	@Test
	public void testUpdateSingleCurrency()
	{
		System.out.println("started DAO testing...");

		VehicleDAO vehicleDAO = new VehicleDAOImpl();	
		Assertions.assertTrue(vehicleDAO!=null);

		Vehicle vehicle=new Vehicle();
		Assertions.assertTrue(vehicle!=null);

		vehicle.setRcNumber("AABB44");
		vehicle.setChasisNumber(999);
		
		vehicle.setDateOfPurchase(Date.valueOf("12-12-19"));
		vehicle.setManufacturer("dummyupdatemanf");
		vehicle.setEngineNumber("dummyupdateengine");
		vehicle.setVehicleModel("dummyupdatemodel");
		vehicle.setCost(500000);
		
		System.out.println("Vehicle : "+vehicle);
		vehicleDAO.updateVehicle(vehicle);
		System.out.println("Vehicle updated....");
	}

	@Test
	public void testDeleteSingleCurrency()
	{
		System.out.println("started DAO testing...");
		
		VehicleDAO vehicleDAO = new VehicleDAOImpl();	
	    Assertions.assertTrue(vehicleDAO!=null);
		
	    vehicleDAO.deleteVehicle("dummyRC");
		System.out.println("Vehicle deleted....");
	}
	
	

}