package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.InsuranceHistory;
import com.java.layer4.InsuranceHistoryService;
import com.java.layer4.InsuranceHistoryServiceImpl;

public class InsuranceHistoryServiceImplTest {

	
	
	
	@Test
	public void findbro() {
		
		InsuranceHistoryService InsuranceHistoryService = new InsuranceHistoryServiceImpl();
		
		System.out.println("hello");
		InsuranceHistoryDAO insuranceHistoryDAO = new InsuranceHistoryDAOImpl();

	Assertions.assertTrue(insuranceHistoryDAO!=null);

		List<InsuranceHistory> inshList = InsuranceHistoryService.findInsuranceHistoryService(102);
	

		for (InsuranceHistory insuranceHistory : inshList) {
			System.out.println("Insurance History : "+insuranceHistory);
		}
		
	}
	
	

}
