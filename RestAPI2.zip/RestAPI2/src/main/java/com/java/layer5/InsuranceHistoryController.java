package com.java.layer5;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.java.layer2.InsuranceHistory;
import com.java.layer4.InsuranceHistoryService;
import com.java.layer4.InsuranceHistoryServiceImpl;

//			project folder-----><-web.xml
// http://localhost:port/RestAPI/rest/  currency/greet
/*
 * virtual tree structure of huge resources
 * 
 * RestAPI
 *   |
 * 	ds <-- web.xml level
 * 	 |
 * 	  rest <-- web.xml level
 * 		  |
 * 		-------------------
 * 		|		|		|
 * 		paris	pune	bengaluru <-- class level
 * 		|		|		|
 * 		greet	greet	greet <-- method level
 * 
 * 
 *  http://ip:port/RestAPI/ds/rest/bengaluru/greet
 *  http://ip:port/RestAPI/ds/rest/pune/greet
 *  http://ip:port/RestAPI/ds/rest/paris/greet

 * 
 */
//layer 5
@Path("/insuranceHistory") 
public class InsuranceHistoryController {
	//global list 
	static List<InsuranceHistory> inshList = new ArrayList<InsuranceHistory>();
	InsuranceHistoryService insuranceHistoryService = new InsuranceHistoryServiceImpl();
	
	public InsuranceHistoryController() { System.out.println("Currency Service called...");}
	// http://ip:port/RestAPI/rest/currency/delete/3
	@DELETE @Path("/delete/{cid}")
	public String deleteIt(@PathParam("cid") int x) {
		boolean found=false;InsuranceHistory insh=null;
		for (InsuranceHistory insuranceHistory : inshList) {
			if(insuranceHistory.getHistoryId() == x) {
				insh= insuranceHistory;
				inshList.remove(insh);
				found=true;
				break;
			}
		}
		if(found==true) return "Currency deleted";
		else return "Currency Not Found :"+x;
	}
	
	// http://ip:port/RestAPI/rest/currency/add
	@POST @Path("/add")
	public String addIt(InsuranceHistory inshObj) {
			insuranceHistoryService.addInsuranceHistoryService(inshObj);
			return "record added successfully";
		
	}
	
	@GET @Path("/find/{pid}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<InsuranceHistory> findIt(@PathParam("pid") int x) {
		
		
		return insuranceHistoryService.findInsuranceHistoryService(x);
	}
	

	@GET @Path("/find")
	@Produces(MediaType.APPLICATION_JSON)
	public List<InsuranceHistory> findall() {
		return insuranceHistoryService.viewAllInsuranceHistoryService();
	}
}
