package com.java.layer4;

import java.util.List;

import com.java.layer2.InsuranceHistory;
import com.java.layer3.InsuranceHistoryDAO;
import com.java.layer3.InsuranceHistoryDAOImpl;


 


public class InsuranceHistoryServiceImpl implements InsuranceHistoryService{

	InsuranceHistoryDAO insuranceHistoryDao = new InsuranceHistoryDAOImpl();
	
	public InsuranceHistoryServiceImpl() {
		System.out.println("InsuranceIssued Service Implementation ctr()..");
	}

	@Override
	public List<InsuranceHistory> viewAllInsuranceHistoryService() {
		List<InsuranceHistory> insuranceList = insuranceHistoryDao.selectAllInsuranceHistory();
		return insuranceList;
	}

	@Override
	public void addInsuranceHistoryService(InsuranceHistory insuranceToAdd)
	{
		insuranceHistoryDao.insertInsuranceHistory(insuranceToAdd);
		 
		System.out.println("Insurance added");
	}
 
	
	

	@Override
	public InsuranceHistory viewInsuranceHistoryService(int historyId) {
		InsuranceHistory insurance = insuranceHistoryDao.selectInsuranceHistory(historyId);
		return insurance;
	}
	
	@Override
	public List<InsuranceHistory> findInsuranceHistoryService(int pid)
	{
		List<InsuranceHistory> insuranceList = insuranceHistoryDao.findInsuranceHistory(pid);
		 
		return insuranceList;
	}
 

	 

}
