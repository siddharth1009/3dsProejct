package com.java.layer4;

import java.util.List;

import com.java.layer2.InsuranceHistory;



public interface InsuranceHistoryService {

	InsuranceHistory viewInsuranceHistoryService(int historyId);
	List<InsuranceHistory> viewAllInsuranceHistoryService();
 

	void addInsuranceHistoryService(InsuranceHistory insuranceHistory);
	List<InsuranceHistory>findInsuranceHistoryService(int pid);
	 
	
	//void removeInsuranceIssuedService(int policyId);

	// float calculateCurrencyService(String s,String t, float amt) throws
	// CurrencyNotFoundException,SourceCurrencyNotFoundException,
	// TargetCurrencyNotFoundException;

}