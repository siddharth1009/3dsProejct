package com.java.layer4;

public class CurrencyAlreadyExistsException extends Exception {
	
	public CurrencyAlreadyExistsException(String str) {
		super(str);
	}
	
}
