package com.java.layer4;

public class SourceCurrencyNotFoundException extends Exception {
	public SourceCurrencyNotFoundException(String str) {
		super(str);
		
	}
}
