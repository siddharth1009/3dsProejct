package com.java.layer3;

import java.util.List;

import com.java.layer2.InsuranceHistory;



public interface InsuranceHistoryDAO
{
	  InsuranceHistory selectInsuranceHistory(int policyId);
		 
	  List<InsuranceHistory> selectAllInsuranceHistory();
	
	  void insertInsuranceHistory(InsuranceHistory insuranceHistory);
	  
	  List<InsuranceHistory> findInsuranceHistory(int pid);

 
	  
}