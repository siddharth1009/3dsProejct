package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.InsuranceHistory;



public class InsuranceHistoryDAOImpl implements InsuranceHistoryDAO {

	Connection conn;


	public InsuranceHistoryDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "Learn@mysql11");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public InsuranceHistory selectInsuranceHistory(int historyId) {
		// TODO Auto-generated method stub
		InsuranceHistory insuranceHistory = null; //make a blank currency object

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsuranceHistory where history="+historyId); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {
				insuranceHistory = new InsuranceHistory();
				insuranceHistory.setHistoryId(result.getInt(1));
				insuranceHistory.setPolicyId(result.getInt(2)); //fill it up column wise
				insuranceHistory.setStartDate(result.getDate(3));
				insuranceHistory.setExpiryDate(result.getDate(4));
				insuranceHistory.setInsuranceTypeId(result.getInt(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insuranceHistory;
	}

	@Override
	public List<InsuranceHistory> selectAllInsuranceHistory() {
		// TODO Auto-generated method stub
		List<InsuranceHistory> insuranceHistoryList = new ArrayList<InsuranceHistory>();//blank list

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("select historyId,policyId,startDate,expiryDate,insuranceName,insuranceDescription,insuranceCost from InsuranceHistory join InsuranceType on InsuranceHistory.insuranceTypeId=InsuranceType.insuranceTypeId;"); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				InsuranceHistory insuranceHistory = new InsuranceHistory();
				insuranceHistory.setHistoryId(result.getInt(1));
				insuranceHistory.setPolicyId(result.getInt(2)); //fill it up column wise
				insuranceHistory.setStartDate(result.getDate(3));
				insuranceHistory.setExpiryDate(result.getDate(4));
				insuranceHistory.setInsuranceName(result.getString(5));
				insuranceHistory.setInsuranceDescription(result.getString(6));
				insuranceHistory.setInsuranceCost(result.getFloat(7));
				insuranceHistoryList.add(insuranceHistory); //push this object in the list
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insuranceHistoryList;
	}

	@Override
	public void insertInsuranceHistory(InsuranceHistory insuranceHistory) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into InsuranceHistory (policyId,startDate,expiryDate,insuranceTypeId) values(?,?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
			pst.setInt(1, insuranceHistory.getPolicyId());
			
			pst.setDate(2, insuranceHistory.getStartDate());
			pst.setDate(3, insuranceHistory.getExpiryDate());
			
			pst.setInt(4, insuranceHistory.getInsuranceTypeId());

			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public List<InsuranceHistory> findInsuranceHistory(int pid) {
		// TODO Auto-generated method stub
		List<InsuranceHistory> insuranceHistoryList = new ArrayList<InsuranceHistory>();//blank list

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("select * from InsuranceHistory where policyId="+pid); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				InsuranceHistory insuranceHistory = new InsuranceHistory();
				insuranceHistory.setHistoryId(result.getInt(1));
				insuranceHistory.setPolicyId(result.getInt(2)); //fill it up column wise
				insuranceHistory.setStartDate(result.getDate(3));
				insuranceHistory.setExpiryDate(result.getDate(4));
				insuranceHistory.setInsuranceTypeId(result.getInt(5));
				insuranceHistoryList.add(insuranceHistory); //push this object in the list
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insuranceHistoryList;
	}

	//delete updt has been omitted

 
}
