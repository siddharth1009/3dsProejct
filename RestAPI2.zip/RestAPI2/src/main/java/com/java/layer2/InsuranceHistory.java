package com.java.layer2;

import java.sql.Date;

public class InsuranceHistory
{
	private int historyId;
	private int policyId;
	private Date startDate;
	private Date expiryDate;
	private int insuranceTypeId;
	public int getInsuranceTypeId() {
		return insuranceTypeId;
	}
	public void setInsuranceTypeId(int insuranceTypeId) {
		this.insuranceTypeId = insuranceTypeId;
	}
	private String insuranceName;
	private String insuranceDescription;
	private float insuranceCost;
	public int getHistoryId() {
		return historyId;
	}
	public void setHistoryId(int historyId) {
		this.historyId = historyId;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	public String getInsuranceDescription() {
		return insuranceDescription;
	}
	public void setInsuranceDescription(String insuranceDescription) {
		this.insuranceDescription = insuranceDescription;
	}
	public float getInsuranceCost() {
		return insuranceCost;
	}
	public void setInsuranceCost(float insuranceCost) {
		this.insuranceCost = insuranceCost;
	}
	@Override
	public String toString() {
		return "InsuranceHistory [historyId=" + historyId + ", policyId=" + policyId + ", startDate=" + startDate
				+ ", expiryDate=" + expiryDate + ", insuranceTypeId=" + insuranceTypeId + ", insuranceName="
				+ insuranceName + ", insuranceDescription=" + insuranceDescription + ", insuranceCost=" + insuranceCost
				+ "]";
	}
	
	
	
	
	 
	
	 
	
	
}
